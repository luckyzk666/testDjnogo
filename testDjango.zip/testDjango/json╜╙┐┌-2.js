// 考卷
$scope.testPaper = {
    'QID': 1,
    'course': '网络编程技术',
    'description': '测试',
    'guideWords': '',

    //填空题
    'completion': [{
        'TID': 0,
        'topic': '计算机中，通常一个字节代表（  ）位二进制，1KB等于（）字节',
        'options': [1, 2] // 表示有两个空，弄两个input
    }],
    //单选题
    'singleChoice': [{
            'TID': 1,
            'topic': 'TCP/IP协议有几层？',
            'options': ['四层', '五层', '六层', '七层'] // 有两个选项
        },
        {
            'TID': 2,
            'topic': '哪个协议是可靠传输的？',
            'options': ['UDP', 'TCP', 'DNS', 'RIP']
        }
    ],
    //多选题
    'multipleChoice': [{
            'TID': 3,
            'topic': '哪些是常用的前端框架',
            'options': ['AngularJS', 'Vue', 'NodeJS', 'Django']
        },
        {
            'TID': 4,
            'topic': '浏览网页最常使用的端口是哪些？',
            'options': ['80', '443', '996', '8848']
        }
    ],
    // 编程题
    'program': [{
        'TID': 5,
        'topic': '设计一个运算器。',
        'lanuageType': 'python'
    }],

    //其他类型的题目（主观题）
    'other': [{
            'title': "简答题",
            'topics': [{ 'TID': 6, 'topic': '什么是TCP?' }, ]
        },
        {
            'title': "论述题",
            'topics': [{ 'TID': 7, 'topic': '论"天下兴亡，匹夫有责"' }, ]
        },
        {
            'title': "作文",
            'topics': [{ 'TID': 8, 'topic': '春天里' }, ]
        },
        {
            'title': "程序阅读题",
            'topics': [{ 'TID': 9, 'topic': '...' }, ]
        }
    ]
}

//答卷
$scope.answerSheet = {
    'AID': 110011, // 答卷ID
    'QID': 1, // 考卷ID，表明是哪份考卷
    'stuID': '1707310226', // 答卷所属的学生学号
    'answers': {
        'completion': [
            // 填空、单选、多选的答案ASN是一个数组
            {
                'TID': 0,
                'ASN': ['8', '1024'] // 每个空所填的答案
            },
        ],
        'singleChoice': [
            { "TID": 1, 'ASN': [0] }, // 选择的 单选题的下标，从0开始
            { 'TID': 2, 'ASN': [2] },
        ],
        'multipleChoice': [
            { 'TID': 3, 'ASN': [1, 2] }, // 选择的多选题的下标，从0开始
            { 'TID': 4, 'ASN': [0, 2] },
        ],
        'program': [
            // 编程题、其他题的ASN是文本
            { 'TID': 5, 'ASN': '#include<stdio.h>....' },
        ],
        'other': [
            [{ 'TID': 6, 'ASN': '什么是TCP?' }, ],
            [{ 'TID': 7, 'ASN': '论"天下兴亡，匹夫有责"' }, ],
            [{ 'TID': 8, 'ASN': '春天里' }, ],
            [{ 'TID': 9, 'ASN': '...' }, ]
        ]
    }
}

//题目答案
$scope.answers = {
    'QID': 1, // 表示哪张考卷
    'answers': {
        'completion': [
            // 填空、单选、多选的答案ASN是一个数组
            {
                'TID': 0,
                'answer': ['8', '1024'] // 表示对应空的值
            },
        ],
        'singleChoice': [{
                "TID": 1,
                'options': ['四层', '五层', '六层', '七层'],
                'answer': 0 // options的下标
            },
            {
                'TID': 2,
                'options': ['UDP', 'TCP', 'DNS', 'RIP'],
                'knowledges': ['TCP/IP协议族'],
                'answer': 1
            },
        ],
        'multipleChoice': [{
                'TID': 3,
                'options': ['AngularJS', 'Vue', 'NodeJS', 'Django'],
                'answer': [0, 1] //正确答案，下标从0开始
            },
            {
                'TID': 4,
                'options': ['80', '443', '996', '8848'],
                'answer': [0, 1]
            },
        ],
        'program': [
            { 'TID': 5, 'answer': '#include<stdio.h>....' },
        ],
        'other': [{
                'title': "简答题",
                'answers': [{ 'TID': 6, 'answer': "略" }, ]
            },
            {
                'title': "论述题",
                'answers': [{ 'TID': 7, 'answer': "略" }, ]
            },
            {
                'title': "作文",
                'answers': [{ 'TID': 8, 'answer': "略" }, ]
            },
            {
                'title': "程序阅读题",
                'answers': [{ 'TID': 9, 'answer': "略" }, ]
            }
        ]
    }
}


// 评分标准
$scope.standard = {
    'QID': 1, // 表示哪张考卷
    'answers': {
        'completion': [
            // 填空、单选、多选的答案ASN是一个数组
            {
                'TID': 0,
                'STD': [2, 2] // standard 标准，每个空的正确的得分,不正确直接不给分
            },
        ],
        'singleChoice': [{
                "TID": 1,
                'STD': [0, 2, 0, 0] // 答案对应下标的分值
            },
            {
                'TID': 2,
                'STD': [0, 2, 0, 0] // 答案对应下标的分值 
            },
        ],
        'multipleChoice': [{
                'TID': 3,
                'STD': [0, 2, 1, 1] // 多选题的得分下标，如果有个错了，应该直接得0分，否则累加
            },
            {
                'TID': 4,
                'STD': [0, 2, 1, 1] // 多选题的得分下标，如果有个错了，应该直接得0分，否则累加 
            },
        ],
        'program': [

            { 'TID': 5, 'STD': 25 },
        ],
        'other': [
            [{ 'TID': 6, 'STD': 5 }, ],
            [{ 'TID': 7, 'STD': 10 }, ],
            [{ 'TID': 8, 'STD': 15 }, ],
            [{ 'TID': 9, 'STD': 15 }, ]
        ]
    }
}


//评卷:对试卷进行评分并统计, 成绩单
$scope.graded = {
    'AID': 110011, // 答卷ID
    'completion': 10,
    'singleChoiceQuestion': 12,
    'multipleChoiceQuestion': 13,
    'program': 30,
    'other': 25,
    'total': 90
}


//课程名称+年级编号
$scope.courses = ['高数01', '大学英语03', '计算机网络原理'];
//题目类型
$scope.questionTypes = ['填空题', '单选题', '多选题', '简答题', '程序运行结果题', '程序设计题'];

//课程知识点列表
$scope.knowledges = [{
        'course': '计算机网络原理',
        'knowledges': ['TCP/IP协议族', 'OSI7层模型', 'CSMA'] //课程知识点列表
    },
    {
        'course': '移动web开发',
        'knowledges': ['前端框架', 'CSS', '端口']
    }
];
//系统支持的计算机程序设计语言
$scope.languages = ['c/c++', 'java', 'python'];

//填空题库
$scope.topicsCompleted = [{
    'course': '计算机网络原理',
    'topics': //填空题库
        [{
        'TID': 0,
        'topic': '计算机中，通常一个字节代表（ ）位二进制，1KB等于（）字节',
        'options': [1, 2], // 表示有两个待填写的空
        'answer': ['8', '1024'], // 表示对应空的值
        'knowledges': ['计算机常识']
    }]
}];


//题库-单选题库
$scope.topicsSingle = [{
    'course': '计算机网络原理',
    'topics': //单选题库
        [{
            'TID': 1,
            'topic': 'TCP/IP协议有几层',
            'options': ['四层', '五层', '六层', '七层'],
            'answer': 0, // options的下标
            'knowledges': ['TCP/IP协议族']
        },
        {
            'TID': 2,
            'topic': '哪个协议是可靠传输的？',
            'options': ['UDP', 'TCP', 'DNS', 'RIP'],
            'answer': 1,
            'knowledges': ['TCP/IP协议族']
        }
    ]
}];

//多选题库
$scope.topicsMutiple = [{
    'course': '移动web开发',
    'topics': //多选题库
        [{
            'TID': 3,
            'topic': '哪些是常用的前端框架',
            'options': ['AngularJS', 'Vue', 'NodeJS', 'Django'],
            'answer': [0, 1], //正确答案，下标从0开始
            'knowledges': ['前端框架']
        },
        {
            'TID': 4,
            'topic': '浏览网页最常使用的端口是哪些？',
            'options': ['80', '443', '996', '8848'],
            'answer': [0, 1],
            'knowledges': ['端口']
        }
    ]
}];




//编程题库
$scope.topicsProgram = [{
    'course': '计算机网络原理',
    'topics': //编程题库
        [{
            'TID': 5,
            'topic': '设计一个运算器。',
            'answer': '',
            'knowledges': [],
            'lanuageType': 'python'
        },
        {
            'TID': 6,
            'topic': '用C编写一个求PI值的程序。',
            'answer': '',
            'knowledges': [],
            'lanuageType': 'c/c++',
        }
    ]
}];

//其他类型的题库
$scope.topicsOther = [{
    'course': '计算机网络原理',
    'questionType': '简答题',
    'topics': //除前面四种外的其他类型题库
        [{
            'TID': 7,
            'topic': 'TCP如何进行拥塞控制？',
            'answer': '略',
            'knowledges': [],
        },
        {
            'TID': 8,
            'topic': 'TCP如何通过3次握手建立连接？',
            'answer': '略',
            'knowledges': [],
        }
    ]
}];

// 所有学生的名单, 假设存了整个学校的学生
$scope.student = [{
        "stuID": "1707310101",
        "name": "张三",
        "class": "网络171",
        "college": "计电学院",
        "school": "广西大学",
        "pwd": "123456" // 密码
    },
    {
        "stuID": "1707310102",
        "name": "李四",
        "class": "网络171",
        "college": "计电学院",
        "school": "广西大学",
        "pwd": "123456"
    }
];

// 考生名单，每一份试卷都有一个考生名单，用QID区分
$scope.stuList = [{
    "QID": 1, // 考卷ID
    "pwd": '123456', // 这份考卷的口令
    "stu": [
        "1707310101", // 允许参加这次考生的学生学号
        "1707310102",
        "1707310103",
        "1707310104"
    ]
}];