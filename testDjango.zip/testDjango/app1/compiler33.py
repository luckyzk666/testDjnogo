﻿import docx
import re
import json

class Compiler33:
    def __init__(self):
        # self.rootdict #根字典
        # self.itemlist#根里面每一项的新增列表
        # self.coursedict#每个课程题库字典
        # self.topicslist#全部题目列表
        # self.topicsdict#单道题目元组
        # self.optionslist#选项列表
        # self.knowledgeslist#知识点列表
        # self.tiku

        #初始化
        self.rootdict={}
        self.itemlist=[]
        self.coursedict={}
        self.topicslist=[]
        self.topicsdict={}
        self.optionslist=[]
        self.knowledgeslist=[]
        self.tiku=""

        #定义正则并编译
        self.pat1 = re.compile(r'\S+、*题库$')
        self.pat2 = re.compile(r'课程+')
        self.pat3=re.compile(r'题型+')
        self.pat4=re.compile(r'\d+、+')
        self.pat5=re.compile(r'[A-Z]{1}\.+')
        self.pat6 = re.compile(r'答案+')
        self.pat7 = re.compile(r'知识点+')

        self.change = {'填空题库':'topicsCompleted', 
            '单选题库':'topicsSingle', 
            '多选题库':'topicsMutiple',
            '编程题库':'topicsProgram',
            '其他类型题库':'topicsOther'}

    #打开word,返回题库内容
    def opendocx(self, path):
        f = docx.Document(path)
        lines = f.paragraphs
        return lines

    #求列表1在列表2中的索引
    def findindex(self, list1,list2):
        cc = []
        for j in list1:
            cc.append(list2.index(j))
        return cc

    #填空题里查找有几个填写项
    def findfill(self, strs):
        pat = re.compile(r'（）')
        n = len(pat.findall(strs))
        alist=[]
        if n > 0:
            for i in range(1,n+1):
                alist.append(i)
        return alist

    #验证正则,执行操作
    def reverify(self, strs,nn,mm):
        #引入全局变量
        self.rootdict  # 根字典
        self.itemlist  # 根里面每一项的新增列表
        self.coursedict  # 每个课程题库字典
        self.topicslist  # 全部题目列表
        self.topicsdict  # 单道题目元组
        self.optionslist  # 选项列表
        self.knowledgeslist  # 知识点列表
        self.tiku

        if(self.pat1.match(strs)):
            m = re.compile(r'\S+、').match(strs).group(0)
            if(self.tiku != ''):
                #self.itemlist.append(self.coursedict)
                self.rootdict[self.tiku].append(self.coursedict)

            self.itemlist = []
            self.coursedict = {}
            self.topicslist = []
            self.topicsdict = {}
            self.optionslist = []
            self.knowledgeslist = []

            self.tiku= self.change.get(strs.replace(m,''))
            self.rootdict[self.tiku] = []
            self.itemlist = []

        elif(self.pat2.match(strs)):
            self.coursedict = {}
            self.coursedict['course'] = strs.replace("课程","").replace("：","").replace(":","")
        elif(self.pat3.match(strs)):
            self.coursedict['topics'] = []
            if self.tiku=='topicsOther':
                self.coursedict['questionType'] = strs.replace("题型","").replace("：","").replace(":","")


        elif(self.pat4.match(strs)):
            self.topicsdict={}
            ind = re.compile(r'\d+、').match(strs).group(0)
            self.topicsdict["TID"] = int(ind.replace('、',''))
            self.topicsdict["topic"] = strs.replace(ind,'')
            if self.tiku == 'topicsCompleted':
                self.optionslist = self.findfill(strs)

        elif(self.pat5.match(strs)):
            ind = re.compile(r'[A-Z]{1}\.').match(strs).group(0)
            self.optionslist.append(strs.replace(ind,''))

        elif(self.pat6.match(strs)):
            if self.tiku == 'topicsSingle':
                self.topicsdict["options"] = self.optionslist
                self.topicsdict["answer"] = self.optionslist.index(strs.replace('答案', '').replace('：', '').replace(':', ''))

            elif self.tiku =='topicsMutiple':
                self.topicsdict["options"] = self.optionslist
                ss = strs.replace('答案', '').replace('：', '').replace(':', '').split("、")
                self.topicsdict["answer"] = self.findindex(ss,self.optionslist)

            elif self.tiku =='topicsCompleted':
                self.topicsdict["options"] = self.optionslist
                self.topicsdict["answer"] = strs.replace('答案', '').replace('：', '').replace(':', '').split("、")

            else:
                self.topicsdict["answer"] = strs.replace('答案', '').replace('：', '').replace(':', '').split("、")

            self.optionslist = []

        elif (self.pat7.match(strs)):

            self.knowledgeslist = strs.replace('知识点','').replace('：','').replace(':','').split("、")
            self.topicsdict["knowledges"] = self.knowledgeslist

            self.topicslist.append(self.topicsdict)
            self.topicsdict={}
            self.coursedict['topics'] = self.topicslist
        else:
            pass

        if nn == mm:
            #self.itemlist.append(self.coursedict)
            self.rootdict[self.tiku].append(self.coursedict)
    



def Tiku2json(path):
    cmp = Compiler33()
    lines =cmp.opendocx(path)
    count = (len(lines)-1)

    for j in range(0,len(lines)):
        cmp.reverify(lines[j].text.strip(),j,count)
    myjson = json.dumps(cmp.rootdict)  # , ensure_ascii=False
    # print(myjson)
    return cmp.rootdict



if __name__=='__main__':
    path='tiku.docx'
    Tiku2json(path)