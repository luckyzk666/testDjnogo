import json,os
import docx,copy

'''
由于我觉得骆保德同学的考卷编译器“动态适应性”比较差，原因是将一些其他题型写入了if-else等固定的代码中，
这样的话只能录入固定的题型
于是我重新写了一个这个编译器；
题型只有五种，分别是：填空题、单选题、多选题、编程题、其他题
除了前4种固定题型之外，所有##开头的都归为其他题。

前三行分别是 course，description和guideWords
然后读取每一行，按照开头分为以下几类：
1、题型是##开头，例如：##单选题
2、题目是数字加点开头，例如：1.什么是网络协议（）？  或者 12.题目一
3、选项是大写字母加点开头，例如：A.TCP
4、空行，不处理跳过

'''

class Compiler31:
    def __init__(self):
        self.letter=['A','B','C','D','E','F','G']
        self.number = [str(i) for i in range(100)]
        self.weiluru=[]
        self.i = 3
    #文件读取模块
    def fileloding(self, path):
        f=docx.Document(path)
        return f
        
    def _deal_one_line(self, oneline):
        oneline = oneline.text
        # print(oneline)
        if oneline.strip() == '':
            # print(0)
            return (0,0)
        elif len(oneline)>2 and oneline[0:2]=='##':
            # print(11)
            return (1, oneline[2:])
        elif len(oneline)>2 and oneline[1]=='.' and oneline[0] in self.number :
            # print(21)
            return (2, oneline[2:])
        elif len(oneline)>3 and oneline[2]=='.' and oneline[0:2] in self.number:
            # print(22)
            return (2, oneline[3:])
        elif len(oneline)>2 and oneline[1] =='.' and oneline[0] in self.letter:
            # print(33)
            return (3, oneline[2:])
        else:
            return (4, oneline)
        
        
    def _optionType(self, line:list, lst:list):
        eachQues = {'TID':0, 'topic': '', 'options':[]}
        while True:
            res = self._deal_one_line(line[self.i])
            if res[0]==0:
                self.i += 1
                continue
            elif res[0] == 1:
                lst.append(copy.deepcopy (eachQues))
                break
            elif res[0] == 2:
                if eachQues['topic'] == '':
                    eachQues['topic'] = res[1]
                    self.i += 1
                else:
                    lst.append(copy.deepcopy (eachQues))
                    eachQues = {'TID':0, 'topic': '', 'options':[]}
            elif res[0] == 3:
                eachQues['options'].append(res[1])
                self.i += 1
            else:
                self.i += 1
                continue

    def _completion(self, line:list, lst:list):
        eachQues = {'TID':0, 'topic': '', 'options':[]}
        while True:
            res = self._deal_one_line(line[self.i])
            if res[0]==0:
                self.i += 1
                continue
            elif res[0] == 1:  #  ##
                break
            elif res[0] == 2:   #  1.
                eachQues['topic'] = res[1]
                for n in range(len(res[1].split("()"))-1):
                    eachQues['options'].append(n+1)
                if len(eachQues['options']) == 0:
                    for n in range(len(res[1].split("（）"))-1):
                        eachQues['options'].append(n+1)
                lst.append(copy.deepcopy(eachQues))
                eachQues = {'TID':0, 'topic': '', 'options':[]}
                self.i += 1
            else:
                self.i += 1
                print("line '{}-{}' 出现错误".format(self.i, res[1]))

    def _progrom(self, line:list, lst:list):
        eachQues = {'TID':0, 'topic': '', 'lanuageType':''}
        while True:
            res = self._deal_one_line(line[self.i])
            if res[0]==0:
                self.i += 1
            elif res[0] == 1:  #  ##
                break
            elif res[0] == 2:   #  1.
                aList = res[1].split("$")
                if len(aList) == 1:
                    print("line '{}-{}' 出现错误, 缺少$".format(self.i, res[1]))
                    langType = '空'
                else:
                    langType = aList[-1]
                eachQues['lanuageType'] = langType
                eachQues['topic'] = res[1][ :-len(langType) -1  ]
                lst.append(copy.deepcopy(eachQues))
                eachQues = {'TID':0, 'topic': '', 'lanuageType':''}
                self.i += 1
            else:
                self.i += 1
                print("line '{}-{}' 出现错误".format(self.i, res[1]))


    def _other(self, line:list, lst:list):
        eachQues = {
            'title': "",
            'topics': [
                # { 'TID': 6, 'topic': '什么是TCP?' }, 
                ]
        }
        oneTi = {'TID':0, 'topic': ''}
        while True:
            if self.i == len(line):
                eachQues['topics'].append(oneTi)
                lst.append(eachQues)
                break
            res = self._deal_one_line(line[self.i])
            if res[0] == 0:
                pass
            elif res[0] == 1:
                print(222,  res[1])
                if eachQues['title'] == "":
                    eachQues['title'] = res[1]
                else:
                    # print("111", eachQues['topics'])
                    eachQues['topics'].append(oneTi)
                    lst.append(eachQues)
                    break
            elif res[0] == 2:
                if oneTi['topic'] == "":
                    oneTi['topic'] = res[1]
                else:
                    eachQues['topics'].append(copy.deepcopy(oneTi))
                    oneTi['topic'] = res[1]
            elif res[0] == 4:
                oneTi['topic'] += '\n' + res[1] 
                # print(oneTi['topic'])
            else:
                print("line '{}-{}' 出现错误".format(self.i, res[1]))
            self.i += 1



    #字典生成
    def jsoning(self, path):
        f = self.fileloding(path)
        line=f.paragraphs
        i=3
        testPaper={
            'course': line[0].text,
            'description': line[1].text,
            'guideWords': line[2].text
        }
        testPaper['other']=[]
        while True:
            if self.i == len(line):
                break
            res = self._deal_one_line(line[self.i])
            if res[0] == 0:
                pass
            elif res[0] == 1:
                print('1',res[1])
                self.i+=1
                if '单选题' in res[1]:
                    testPaper['singleChoice']=[]
                    self._optionType(line, testPaper['singleChoice'])
                elif '多选题' in res[1]:
                    testPaper['multipleChoice']=[]
                    self._optionType(line, testPaper['multipleChoice'])
                elif '填空题' in res[1]:
                    testPaper['completion']=[]
                    self._completion(line, testPaper['completion'])
                elif '编程题' in res[1]:
                    testPaper['program']=[]
                    self._progrom(line, testPaper['program'])
                else:
                    self.i -= 1
                    self._other(line, testPaper['other'])
                continue
            self.i+=1
        return testPaper

if __name__=='__main__':
    path='./testpaper3.docx'
    if os.path.exists(path):
        print("文件不存在：", path)
        exit(0)
    aaa = Compiler31()
    testPaper = aaa.jsoning(path)
    print(json.dumps(testPaper))