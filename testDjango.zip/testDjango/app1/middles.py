
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponse

# 允许跨域的中间件
class MyCorsMiddle(MiddlewareMixin):
    def process_request(self, request):
        if request.method == 'OPTIONS':
            resp = HttpResponse('')
            resp['Access-Control-Allow-Origin'] = '*'
            resp['Access-Control-Allow-Headers'] = '*'
            return resp
        return None  # 正常的请求返回None表示不处理

    def process_response(self, request, response):
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Headers'] = '*'
        return response