# encoding:utf-8
from django.shortcuts import render
from django.http import HttpResponse, StreamingHttpResponse
import os, json
from testDjango.settings import BASE_DIR, HTML_PATH
from app1.compiler_3_1copy import Compiler31
from app1 import compiler33
import mimetypes
from wsgiref.util import FileWrapper
# Create your views here.

# data存储了所有的json，相当于数据库
data = dict({
    'maxQID': 1,
    'maxTID': 1,
    'maxAID': 1,
    'answers': '[]', #考卷的答案
    'standard': '[]',  # 考卷的评分标准
    'answerSheet': '[]',  # 答案
    'graded': '[]',
    'stuList': '[]',
    'student': '[]',
    'teacher': '[{"name":"admin", "pwd": "admin"}]',
    'knowledges': '[]',
    'testPapers': '[]',
    'tiku': '''{
        "topicsCompleted": [],
        "topicsSingle": [],
        "topicsMutiple":  [],
        "topicsProgram": [],
        "topicsOther": []
    }'''
})  # key, value（字符串）
fp = os.path.join(BASE_DIR, "app1", "jsons", "data" )
if os.path.exists(fp):
        with open(fp, 'r') as f:
            data = json.load(f)

docxPath = os.path.join(BASE_DIR, "app1", "docx", "temp.docx" )

# 返回所有存在的json
def all(req):
    text = "<div> http://hhq-yyq.xyz/json/对应的key, GET可以获取对应value字符串，POST可以设置</div><br>"
    fm = "<div>key:{}, value: <xmp style='white-space:normal;'>{}</xmp></div><br>"
    for k,v in data.items():
        text+=fm.format(k,v)
    return HttpResponse(text.encode())

# 获取和设置json
def getJson(req, name):
    print(name)
    if req.method == "GET":
        if name in data.keys():
            return HttpResponse(data.get(name).encode())
        else:
            return HttpResponse(b"")
    else:

        data[name] = req.body.decode()
        # print(req.body)
        with open(fp, "w") as f:
            json.dump(data, f)
        return HttpResponse("SUCC")

# 删除考卷json, 极其相关所有数据，包括答卷、答案、标准、考生列表
def delTestPaper(req, QID):
    testPapers = json.loads(data['testPapers'])
    answerSheet = json.loads(data['answerSheet'])
    answers = json.loads(data['answers'])
    standard = json.loads(data['standard'])
    stuList = json.loads(data['stuList'])
    graded = json.loads(data['graded'])
    tmp = [testPapers, answerSheet, answers, standard, stuList]
    AIDList = []
    for j, lst in enumerate(tmp):
        for i,v in enumerate(lst):
            if int(v['QID']) == QID:
                sheet = v.get('AID')
                if sheet:
                    AIDList.append(sheet)
                del tmp[j][i]
    for i,grade in enumerate (graded):
        if grade['AID'] in AIDList:
            del graded[i]
    data['testPapers'] = json.dumps(testPapers)
    data['answerSheet'] = json.dumps(answerSheet)
    data['answers'] = json.dumps(answers)
    data['standard'] = json.dumps(standard)
    data['stuList'] = json.dumps(stuList)
    data['graded'] = json.dumps(graded)
    _save(data)
    return HttpResponse("succ")


# QID获取某一份考卷
def get_testPaper(req, QID):
    testPapers = json.loads(data.get('testPapers') or '[]') 
    for paper in testPapers:
        if paper.get("QID") == QID:
            return HttpResponse(json.dumps(paper))
    return HttpResponse("") # 不存在则返回空

# 入库考卷GUI,
def insert_paper_by_GUI(req):
    if req.method == "POST":
        testPaper = json.loads(req.body.decode())
        if _insert_testPaper(testPaper):  # 将考卷json入库的 函数
            return HttpResponse("succ") 
        else:
            return HttpResponse("error！出现未知错误！请确保考卷的json格式正确") 
    else:
        return HttpResponse("请使用  POST 方法")

# 入库考卷GUI, 不改变TID
def insert_paper_by_GUI_no(req):
    if req.method == "POST":
        testPaper = json.loads(req.body.decode())
        print(req.body.decode())
        if _insert_testPaper(testPaper, False):  # 将考卷json入库的 函数
            return HttpResponse("succ") 
        else:
            return HttpResponse("error！出现未知错误！请确保考卷的json格式正确") 
    else:
        return HttpResponse("请使用  POST 方法")

# 入库考卷，调用编译器3.1
def insert_paper_by_CMP(req):
    if req.method == "POST":
        myFile =req.FILES.get("myfile", None) 
        if myFile:
            with open(docxPath, "wb") as f:
                for chunk in myFile.chunks():
                    f.write(chunk)
            testPaper = Compiler31().jsoning(docxPath)
            if _insert_testPaper(testPaper):
                return HttpResponse("succ") 
            else:
                return HttpResponse("error！出现未知错误！请确保考卷的json格式正确") 
        else:
            return HttpResponse("error！无法获取文件") 
    else:
        return HttpResponse("请使用  POST 方法")

# 将一个考卷字典对象赋值QID和TID后，入库
def _insert_testPaper(testPaper, newTID=True):
    try:
        testPapers = json.loads(data.get('testPapers') or '[]') 
        maxQID = data.get('maxQID')
        maxQID += 1
        testPaper["QID"] = maxQID  # 将上传的考卷的QID变为最大的QID
        maxTID = data.get('maxTID')  # 最大TID
        if newTID:
            itemType = ['completion', 'singleChoice', 'multipleChoice', 'program']
            for each in testPaper.keys():
                if each in itemType:  # 基本题型
                    for item in testPaper[each]:
                        maxTID += 1
                        item['TID'] = maxTID  # 给每道题赋予一个最新的TID
                # 其他题型
                elif each == 'other':
                    for oneType in testPaper['other']:  
                        for item in oneType['topics']:
                            maxTID += 1
                            item["TID"] = maxTID
        # 将更新纳入“数据库”
        data["maxQID"] = maxQID
        data["maxTID"] = maxTID
        testPapers.append(testPaper)  # 添加 试卷 到 试卷集
        data["testPapers"] =  json.dumps(testPapers)  # 注意要转为字符串
        _save(data)
        print(json.dumps(testPaper))
        return True
    except Exception as e:
        print(e)
        return False


# 获取和设置 答案answers，根据QID
def answers(req, QID):
    if req.method == "GET":  # 获取
        answers = json.loads(data.get("answers"))
        for answer in answers:
            if answer.get("QID") == QID:
                return HttpResponse(json.dumps(answer))
        return HttpResponse("")
    # 若是POST方法   设置
    elif req.method == "POST":
        answers = json.loads(data.get("answers"))
        answer = json.loads(req.body.decode())
        noExist = True
        for i,v in enumerate(answers):
            if v.get("QID") == QID:
                answers[i] = answer
                noExist=False
        if noExist:
            answers.append(answer)
        data['answers'] = json.dumps(answers)
        _save(data)
        return HttpResponse("succ")
    else:
        return HttpResponse("")


# 根据QID 获取、设置 评分标准standard
def standard(req, QID):
    if req.method == "GET":  # 获取
        standard = json.loads(data.get("standard"))
        for std in standard:
            if std.get("QID") == QID:
                return HttpResponse(json.dumps(std))
        return HttpResponse("")
    # 若是POST方法   设置
    elif req.method == "POST":
        standard = json.loads(data.get("standard"))
        std = json.loads(req.body.decode())
        noExist = True
        for i,v in enumerate(standard):
            if v.get("QID") == QID:
                standard[i] = std
                noExist=False
        if noExist:
            standard.append(std)
        data['standard'] = json.dumps(standard)
        _save(data)
        return HttpResponse("succ")
    else:
        return HttpResponse("")

# 上传题库文件
def upload_tiku_cmp(req):
    if req.method == "POST":
        myFile =req.FILES.get("myfile", None) 
        if myFile:
            with open(docxPath, "wb") as f:
                for chunk in myFile.chunks():
                    f.write(chunk)
            tik = compiler33.Tiku2json(docxPath)
            _tiku_insert(tik)
            return HttpResponse("succ") 
        else:
            return HttpResponse("error！无法获取文件") 
    else:
        return HttpResponse("请使用  POST 方法")

# 上传json题库
def upload_tiku_GUI(req):
    if req.method == "POST":
        tik = json.loads(req.body.decode())
        _tiku_insert(tik)
        return HttpResponse("succ") 
    else:
        return HttpResponse("请使用  POST 方法")

# 将题库合并为 总的题库json
def _tiku_insert(tik):
    maxTID = data.get('maxTID')
    TIKU = json.loads(  data.get('tiku') )  # 总题库
    for k,v in tik.items():
        for i in v:  # k是 topiscCompleted、topicsSingle之类的
            for j in i['topics']:  # i是某门课程的题库
                maxTID += 1
                j['TID'] = maxTID
            coureNoExist = True
            for courseTiku in TIKU[k]:
                # print(courseTiku, i)
                if courseTiku['course'] == i['course']:
                    courseTiku['topics'].extend(i['topics'])
                    coureNoExist = False
            if coureNoExist:
                TIKU[k].append(i)
    data["maxTID"] = maxTID
    data['tiku'] = json.dumps(TIKU)
    _save(data) 


# 保存data到文件
def _save(data):
    with open(fp, 'w') as f:
            json.dump(data, f)



# 返回静态文件
def mystatic(req):
    path =  BASE_DIR + req.path_info 
    print('MY STATIC', path)
    if(os.path.exists(path)):
        content_type, encoding = mimetypes.guess_type(path)
        resp = StreamingHttpResponse(FileWrapper(open(path, 'rb')), content_type=content_type)
        resp['Cache-Control']="max-age=8640000"
    else:
        resp = HttpResponse("", status=404)
    return resp
        

# 返回html,js,css
def files(req):
    path = HTML_PATH + req.path_info
    print(path)
    if(os.path.exists(path)):
        content_type, encoding = mimetypes.guess_type(path)
        resp = StreamingHttpResponse(FileWrapper(open(path, 'rb')), content_type=content_type)
        # resp['Cache-Control']="max-age=8640000"
    else:
        resp = HttpResponse("", status=404)
    return resp

# 获取和设置答卷
def answerSheet(req,QID,stuID):
    if req.method == 'GET':
        answerSheet = json.loads(data['answerSheet'])
        for val in answerSheet:
            if val['QID']==QID and val['stuID']==stuID:
                return HttpResponse(json.dumps(val))
        return HttpResponse("")
    else:
        sheet = json.loads(req.body.decode())
        answerSheet = json.loads(data['answerSheet'])
        maxAID = data['maxAID']
        noExist=True
        for i, val in enumerate(answerSheet):
            if val['QID']==QID and val['stuID']==stuID:
                answerSheet[i] = sheet
                noExist = False
                break
        if noExist:
            maxAID += 1
            sheet["AID"] = maxAID
            data['maxAID'] = maxAID
            answerSheet.append(sheet)
        data['answerSheet']=json.dumps(answerSheet)
        _save(data)
        return HttpResponse('succ')    


# 列出所有考卷，以及附属信息，包括：是否录入答案、评分标准、录入考生、交卷考生
def list_testPaper(req):
    testPaper = json.loads(data['testPapers'])
    if testPaper == []:
        return HttpResponse("[]")
    answers = json.loads(data['answers'])
    standard = json.loads(data['standard'])
    answerSheet = json.loads(data['answerSheet'])
    stuList = json.loads(data['stuList'])
    paperDict = {}  # QID 对应的testPaper下标
    for i,v in enumerate(testPaper):
        testPaper[i]['hasAnswer']=0   # 是否录入答案
        testPaper[i]['hasStandard']=0  # 是否录入评分标准
        testPaper[i]['answerSheet']=[]    # 该考卷已经完成的答卷
        testPaper[i]['stuList'] = {'stu':None}   # 考生名单
        paperDict[v['QID']] = i    # # QID 对应的testPaper下标
    for ans in answers:
        i = paperDict [ ans['QID'] ]
        testPaper[i]['hasAnswer'] = 1   # 已经录入答案
    for std in standard:
        i = paperDict[std['QID']]
        testPaper[i]['hasStandard']=1
    for sheet in answerSheet:
        i = paperDict[sheet['QID']]
        testPaper[i]['answerSheet'].append(sheet)
    for lst in stuList:
        i = paperDict[lst['QID']]
        testPaper[i]['stuList'] = lst

    return HttpResponse(json.dumps(testPaper))


# # 根据QID获取一些数据
# def get_some_json(req, key, QID):
#     jsonString = data.get(key)
#     if jsonString:
#         objList = json.loads(jsonString)
#         for item in objList:
#             oneQID = item.get('QID')
#             if not oneQID:
#                 break
#             if oneQID == QID:
#                 return HttpResponse(json.dumps(item))
#     return HttpResponse("")

# 根据AID获取和上传评阅
def get_graded(req, AID):
    if req.method == "POST":
        oneGraded = json.loads(req.body.decode())
        graded = json.loads(data['graded'])
        noExist = True
        for i,v in enumerate (graded):
            if v.get('AID') == AID:
                noExist = False
                graded[i] = oneGraded
                break
        if noExist:
            graded.append(oneGraded)
        data["graded"] = json.dumps(graded)
        _save(data)
        return HttpResponse('succ')
    else:
        graded = json.loads(data['graded'])
        for item in graded:
            if item.get('AID') == AID:
                return HttpResponse(json.dumps(item))
    return HttpResponse("")






