// var app = angular.module('app', []);

app.controller('answerCtrl', function($scope, $http, $location, $rootScope) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=answer")
        return
    }
    $scope.QID = parseInt($location.search().QID)
    $http.get($rootScope.HOST + '/get_testPapers/' + $scope.QID).then(function(res) {
        $scope.testPaper = angular.fromJson(res.data);
        console.log(res.data);
    }).catch(function() {
        alert("失败");
    });
    $scope.answers = {
        'QID': parseInt($scope.QID), // 表示哪张考卷
        'answers': {
            'completion': [],
            'singleChoice': [],
            'multipleChoice': [],
            'program': [],
            'other': []
        }
    }

    $scope.check = function() {
        // alert('点了提交');
        //填空
        for (var i = 0; i < $scope.testPaper.completion.length; i++) {
            var question = $scope.testPaper.completion[i];
            $scope.answers.answers.completion[i] = {
                'TID': question.TID,
                'answer': question.answer,
            }
        }
        //单选
        for (var i = 0; i < $scope.testPaper.singleChoice.length; i++) {
            var question = $scope.testPaper.singleChoice[i];
            $scope.answers.answers.singleChoice[i] = {
                'TID': question.TID,
                'options': question.options,
                'answer': parseInt(question.answer),
            }
        }
        //多选
        for (var i = 0; i < $scope.testPaper.multipleChoice.length; i++) {
            var question = $scope.testPaper.multipleChoice[i];
            $scope.answers.answers.multipleChoice[i] = {
                'TID': question.TID,
                'options': question.options,
                'answer': $scope.runEach($scope.mysplit(question.answer), parseInt),
            }
            console.log($scope.answers.answers.multipleChoice[i])
        }
        //编程题
        for (var i = 0; i < $scope.testPaper.program.length; i++) {
            var question = $scope.testPaper.program[i];
            $scope.answers.answers.program[i] = {
                'TID': question.TID,
                'answer': question.answer || '',
            }
        }
        //其他题型
        for (var i = 0; i < $scope.testPaper.other.length; i++) {
            $scope.answers.answers.other.push({
                'title': $scope.testPaper.other[i].title,
                'answers': []
            })
            for (var j = 0; j < $scope.testPaper.other[i].topics.length; j++) {
                console.log($scope.testPaper.other[i].topics[j])
                var question = $scope.testPaper.other[i].topics[j];
                $scope.answers.answers.other[i].answers.push({
                    'TID': question.TID,
                    'answer': question.answer || '',
                })
            }

        }


        $http.post($rootScope.HOST + '/answers/' + $scope.QID,
            angular.toJson($scope.answers)).then(function() {
            alert('提交成功');
            $location.url("/listPaper")
        }).catch(function() {
            alert('提交失败');
        })
    }
    $scope.mysplit = function(ss) {
        res = ss.split(',');
        return res;
    }
    $scope.myMerge = function(Arr) {
        var res = ""
        for (var i = 0; i < Arr.length; i++) {
            res += Arr[i] + ',';
        }
        return res
    }
    $scope.runEach = function(Arr, fun) {
        var res = [];
        for (var i = 0; i < Arr.length; i++) {
            res.push(fun(Arr[i]))
        }
        return res
    }
})