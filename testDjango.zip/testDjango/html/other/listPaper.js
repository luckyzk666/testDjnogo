app.controller('listPaperCtrl', function($scope, $rootScope, $http, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=listPaper")
        return
    }
    $scope.selectedSheet = undefined
    $scope.getData = function() {
        $http.get($rootScope.HOST + '/list_testPaper')
            .then(function(res) {
                $scope.testPaper = angular.fromJson(res.data);
            });
        $http.get($rootScope.HOST + '/json/graded')
            .then(function(res) {
                var gradeList = angular.fromJson(res.data);
                $scope.graded = {}
                for (var i = 0; i < gradeList.length; i++) {
                    $scope.graded['AID' + gradeList[i].AID] = gradeList[i]
                }
            })
    }

    $scope.delTestPaper = function(QID) {
        // console.log($rootScope.HOST + "/delTestPaper/" + QID)
        $http.get($rootScope.HOST + "/delTestPaper/" + QID)
            .then(function(res) {
                if (res.data == "succ") {
                    $scope.getData()
                    alert("删除成功")
                }
            })
    }

    $scope.getData()

});