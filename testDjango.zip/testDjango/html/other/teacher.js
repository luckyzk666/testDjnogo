app.controller('teacherCtrl', function($scope, $rootScope, $location, $http) {
    if ($location.search().url) {
        $scope.url = $location.search().url;
    }
    $http.get($rootScope.HOST + '/json/teacher')
        .then(function(res) {
            console.log(angular.fromJson(res.data))
            $scope.teacher = angular.fromJson(res.data)
        })


    $scope.teacherID = 'admin'
    $scope.teacherPwd = 'admin'
        // 注册教师
    $scope.add = function() {
            var noExist = true;
            for (var i = 0; i < $scope.teacher.length; i++) {
                if ($scope.teacherID == $scope.teacher[i].name) {
                    noExist = false
                    break
                }
            }
            if (!noExist) {
                alert("该教师已经存在，无法重复注册")
            } else {
                $scope.teacher.push({
                    'name': $scope.teacherID,
                    'pwd': $scope.teacherPwd
                })
                $http.post($rootScope.HOST + '/json/teacher', angular.toJson($scope.teacher))
                    .then(function() {
                        alert("注册成功，请牢记：用户名[%s], 密码[%s]".format($scope.teacherID, $scope.teacherPwd))
                    }).catch(function() {
                        alert("服务器错误")
                    })

            }
        }
        // 登陆
    $scope.login = function() {
        var noExist = true;
        for (var i = 0; i < $scope.teacher.length; i++) {
            if ($scope.teacherID == $scope.teacher[i].name &&
                $scope.teacherPwd == $scope.teacher[i].pwd) {
                noExist = false
                break
            }
        }
        if (!noExist) {
            localStorage.setItem("teaID", $scope.teacherID);
            $rootScope.teaID = $scope.teacherID
            if ($scope.url) {
                $location.url($scope.url)
            } else {
                alert("登陆成功");
            }
        } else {
            alert("不存在该教师，请确保输入正确")
        }
    }

    // 离开
    $scope.leave = function() {
        localStorage.removeItem("teaID")
        $rootScope.teaID = null
        alert('退出成功')
    }

})