app.controller('stuLoginCtrl', function($scope, $rootScope, $location, $http) {
    // $rootScope.HOST = 'http://localhost:8000';
    if ($location.search().url) {
        $scope.url = $location.search().url;
    }
    $http.get($rootScope.HOST + '/json/student')
        .then(function(res) {
            console.log(angular.fromJson(res.data))
            $scope.student = angular.fromJson(res.data)
        })

    $scope.stuID = '1707310226'
    $scope.stuPwd = '123456'
        // 注册
    $scope.add = function() {
            $location.url("/stuReg")
        }
        // 登陆
    $scope.login = function() {
        var noExist = true;
        for (var i = 0; i < $scope.student.length; i++) {
            if ($scope.stuID == $scope.student[i].stuID &&
                $scope.stuPwd == $scope.student[i].pwd) {
                noExist = false
                break
            }
        }
        if (!noExist) {
            localStorage.setItem("stuID", $scope.stuID)
            $rootScope.stuID = $scope.stuID
            if ($scope.url) {
                $location.url($scope.url)
            } else {
                alert("登陆成功")
                $location.url('/stuView')
            }
        } else {
            alert("不存在该学生，请确保输入正确")
        }
    }

    // 离开
    $scope.leave = function() {
        localStorage.removeItem("stuID")
        $rootScope.stuID = null
        alert('退出成功')
    }

})