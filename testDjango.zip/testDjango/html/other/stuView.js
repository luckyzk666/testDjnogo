app.controller('stuViewCtrl', function($scope, $rootScope, $http, $location) {
    if (localStorage.getItem("stuID") == null) {
        $location.url("/stuLogin?url=stuView")
        return
    }
    $scope.stuID = localStorage.getItem("stuID")
    $scope.selectedSheet = undefined
    $scope.flag = 0
    $scope.getData = function() {
        $http.get($rootScope.HOST + '/list_testPaper')
            .then(function(res) {
                $scope.testPaper = angular.fromJson(res.data);
                if (++$scope.flag == 2) {
                    $scope.init()
                }
            });
        $http.get($rootScope.HOST + '/json/graded')
            .then(function(res) {
                var gradeList = angular.fromJson(res.data);
                $scope.graded = {}
                for (var i = 0; i < gradeList.length; i++) {
                    $scope.graded['AID' + gradeList[i].AID] = gradeList[i]
                }
                if (++$scope.flag == 2) {
                    $scope.init()
                }
            })
    }

    $scope.getData()
    $scope.init = function() {
        $scope.myPaper = []
        for (var i = 0; i < $scope.testPaper.length; i++) {
            var stuList = $scope.testPaper[i].stuList.stu || [];
            for (var j = 0; j < stuList.length; j++) {
                if (stuList[j] == $scope.stuID) {
                    $scope.myPaper.push($scope.testPaper[i])
                    break
                }
            }
        }
        console.log($scope.myPaper)
        for (var i = 0; i < $scope.myPaper.length; i++) {
            var sheet = $scope.myPaper[i].answerSheet;
            for (var j = 0; j < sheet.length; j++) {
                if (sheet[j].stuID == $scope.stuID) {
                    $scope.myPaper[i].hasSheet = true // 表示已经提交答卷
                }
                if ($scope.graded['AID' + sheet[j].AID]) {
                    $scope.myPaper[i].hasGrade = true // 表示老师已经评阅
                    $scope.myPaper[i].grade = $scope.graded['AID' + sheet[j].AID]
                }
            }
        }
    }

});