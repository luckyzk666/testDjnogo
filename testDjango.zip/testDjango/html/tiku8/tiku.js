app.controller("tikuController", function($scope, $http, $rootScope, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=tiku")
        return
    }
    //获取各题库数据
    $scope.getData = function() {
        $scope.tiku = {
            "topicsCompleted": [],
            "topicsSingle": [],
            "topicsMutiple": [],
            "topicsProgram": [],
            "topicsOther": []
        }
        $scope.datacompleted = [{
            'course': '计算机网络原理',
            'topics': []
        }]
        $scope.datamultiple = [{
            'course': '计算机网络原理',
            'topics': []
        }]
        $scope.datasingle = [{
            'course': '计算机网络原理',
            'topics': []
        }]
        $scope.dataprogram = [{
            'course': '计算机网络原理',
            'topics': []
        }]
        $scope.dataessay = [{
            'course': '计算机网络原理',
            'questionType': '简答题',
            'topics': []
        }]
        console.log($scope.tiku);
    }

    //获取输入的题目数据
    $scope.initClear = function() {
        $scope.getData()
        $scope.oneCompletedQuestion = {
            'TID': 0,
            'topic': '',
            'options': [],
            'answer': [],
            'knowledges': []
        }
        $scope.oneSingleQuestion = {
            'TID': 0,
            'topic': '',
            'options': [],
            'answer': 0, // options的下标
            'knowledges': []
        }
        $scope.oneMultipleQuestion = {
            'TID': 0,
            'topic': '',
            'options': [],
            'answer': [], // options的下标
            'knowledges': []
        }
        $scope.oneProgramQuestion = {
            'TID': 0,
            'topic': '',
            'answer': '',
            'knowledges': [],
            'lanuageType': ''
        }

        $scope.oneEssayQuestion = {
            'TID': 0,
            'topic': '',
            'answer': '',
            'knowledges': []
        }
    }
    $scope.initClear();
    //将题目添加到对应的题库中
    $scope.addc = function() { // 填空
        var op = $scope.oneCompletedQuestion.options[0];
        $scope.oneCompletedQuestion.options = $scope.runEach($scope.mysplit(op), parseInt);
        var ans = $scope.oneCompletedQuestion.answer[0];
        $scope.oneCompletedQuestion.answer = $scope.mysplit(ans);
        $scope.oneCompletedQuestion.knowledges = $scope.mysplit($scope.oneCompletedQuestion.knowledges[0])
        $scope.datacompleted[0].topics.push($scope.oneCompletedQuestion)
        $scope.tiku.topicsCompleted = $scope.datacompleted;
        $scope.myPost()
    }
    $scope.adds = function() {
        $scope.oneSingleQuestion.knowledges = $scope.mysplit($scope.oneSingleQuestion.knowledges[0])
        $scope.datasingle[0].topics.push($scope.oneSingleQuestion)
        $scope.tiku.topicsSingle = $scope.datasingle;
        $scope.myPost()
    }
    $scope.addm = function() {
        var an = $scope.oneMultipleQuestion.answer[0];
        $scope.oneMultipleQuestion.answer = $scope.runEach($scope.mysplit(an), parseInt);
        $scope.oneMultipleQuestion.knowledges = $scope.mysplit($scope.oneMultipleQuestion.knowledges[0])
        $scope.datamultiple[0].topics.push($scope.oneMultipleQuestion)
        $scope.tiku.topicsMutiple = $scope.datamultiple;
        $scope.myPost()
    }

    $scope.addp = function() {
        $scope.oneProgramQuestion.knowledges = $scope.mysplit($scope.oneProgramQuestion.knowledges[0])
        $scope.dataprogram[0].topics.push($scope.oneProgramQuestion)
        $scope.tiku.topicsProgram = $scope.dataprogram;
        $scope.myPost()
    }
    $scope.adde = function() {
        $scope.oneEssayQuestion.knowledges = $scope.mysplit($scope.oneEssayQuestion.knowledges[0])
        $scope.dataessay[0].topics.push($scope.oneEssayQuestion)
        $scope.tiku.topicsOther = $scope.dataessay;
        $scope.myPost()
    }

    //将添加好的题目post到网站
    $scope.myPost = function() {
        $http.post($rootScope.HOST + '/upload_tiku_GUI',
                angular.toJson($scope.tiku))
            .then(function() {
                console.log(angular.toJson($scope.tiku));
                alert('题目添加成功');
                $scope.initClear();
            }).catch(function() {
                alert("失败");
            });

    }

    $scope.mysplit = function(ss) {
        res = ss.split(',');
        return res;
    }
    $scope.myMerge = function(Arr) {
        var res = ""
        for (var i = 0; i < Arr.length; i++) {
            res += Arr[i] + ',';
        }
        return res
    }
    $scope.runEach = function(Arr, fun) {
        var res = [];
        for (var i = 0; i < Arr.length; i++) {
            res.push(fun(Arr[i]))
        }
        return res
    }

});