// author: 霍华骑

app.controller("gui7Ctrl", function($scope, $http, $rootScope, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=gui7")
        return
    }
    $http.get($rootScope.HOST + "/json/tiku")
        .then(function(res) {
            $scope.tiku = res.data;
            console.log($scope.tiku)
            $scope.getAllCourse()
            $scope.reset()
            $scope.changeTiku()
        })
        .catch(function() {
            alert("无法获取题库")
        })

    $scope.reset = function() {
        $scope.testPaper = { // 要生成的考卷
            'QID': 1,
            'course': $scope.courseList[0] || "空",
            'description': '',
            'guideWords': '',
            //填空题
            'completion': [],
            //单选题
            'singleChoice': [],
            //多选题
            'multipleChoice': [],
            // 编程题
            'program': [],
            //其他类型的题目（主观题）
            'other': []
        }
        $scope.slTopci = { // 选中的题目
            "com": "",
            "sin": "",
            "mul": "",
            "pro": '',
            "other": ''
        }
    }
    $scope.allTID = []
    $scope.tiNum = 5

    $scope.slTopci = {
        "com": "",
        "sin": "",
        "mul": "",
        "pro": '',
        "other": ''
    }
    $scope.getAllCourse = function() {
            $scope.courseList = new Set() // 题库中的所有课程名
            for (let key in $scope.tiku) {
                let oneKuList = $scope.tiku[key]
                for (var i = 0; i < oneKuList.length; i++) {
                    $scope.courseList.add(oneKuList[i].course);
                }
            }
            $scope.courseList = Array.from($scope.courseList)
        }
        // 更改course时候更新待选题库
    $scope.changeTiku = function() {
            $scope.tikuCopy = {}
            for (let key in $scope.tiku) {
                let oneKuList = $scope.tiku[key]
                $scope.tikuCopy[key] = { topics: [] }
                for (var i = 0; i < oneKuList.length; i++) {
                    if (oneKuList[i].course == $scope.testPaper.course) {
                        if (key != "topicsOther") {
                            $scope.tikuCopy[key] = angular.copy(oneKuList[i])
                            for (var j = 0; j < oneKuList[i].topics.length; j++) {
                                $scope.allTID.push(oneKuList[i].topics[j].TID)
                            }
                            break
                        } else { // 将其他题的questionType暂时存储到每一题的type属性上
                            for (var j = 0; j < oneKuList[i].topics.length; j++) {
                                oneKuList[i].topics[j].type = oneKuList[i].questionType
                                $scope.allTID.push(oneKuList[i].topics[j].TID)
                            }
                            $scope.tikuCopy[key].topics = $scope.tikuCopy[key].topics.concat(oneKuList[i].topics)
                        }
                    }
                }
            }
            console.log($scope.allTID)
            console.log($scope.tikuCopy)
        }
        // 添加一道题
    $scope.add = function(flag) {
            if ($scope.slTopci[flag] == "")
                return
            var noExist = true
            switch (flag) {
                case 'com':
                    for (var i = 0; i < $scope.testPaper.completion.length; i++) {
                        if ($scope.testPaper.completion[i].TID == $scope.slTopci.com.TID) {
                            noExist = false;
                            break;
                        }
                    }
                    if (noExist)
                        $scope.testPaper.completion.push({
                            TID: $scope.slTopci.com.TID,
                            topic: $scope.slTopci.com.topic,
                            options: $scope.slTopci.com.options
                        });
                    break;
                case 'sin':
                    for (var i = 0; i < $scope.testPaper.singleChoice.length; i++) {
                        if ($scope.testPaper.singleChoice[i].TID == $scope.slTopci.sin.TID) {
                            noExist = false;
                            break;
                        }
                    }
                    if (noExist)
                        $scope.testPaper.singleChoice.push({
                            TID: $scope.slTopci.sin.TID,
                            topic: $scope.slTopci.sin.topic,
                            options: $scope.slTopci.sin.options
                        });
                    break;
                case 'mul':
                    for (var i = 0; i < $scope.testPaper.multipleChoice.length; i++) {
                        if ($scope.testPaper.multipleChoice[i].TID == $scope.slTopci.mul.TID) {
                            noExist = false;
                            break;
                        }
                    }
                    if (noExist)
                        $scope.testPaper.multipleChoice.push({
                            TID: $scope.slTopci.mul.TID,
                            topic: $scope.slTopci.mul.topic,
                            options: $scope.slTopci.mul.options
                        });
                    break;
                case 'pro':
                    for (var i = 0; i < $scope.testPaper.program.length; i++) {
                        if ($scope.testPaper.program[i].TID == $scope.slTopci.pro.TID) {
                            noExist = false;
                            break;
                        }
                    }
                    if (noExist)
                        $scope.testPaper.program.push({
                            TID: $scope.slTopci.pro.TID,
                            topic: $scope.slTopci.pro.topic,
                            lanuageType: $scope.slTopci.pro.lanuageType
                        });
                    break;
                case 'other':
                    for (var i = 0; i < $scope.testPaper.other.length; i++) {
                        if ($scope.testPaper.other[i].TID == $scope.slTopci.other.TID) {
                            noExist = false;
                            break;
                        }
                    }
                    if (noExist)
                        $scope.testPaper.other.push({
                            TID: $scope.slTopci.other.TID,
                            topic: $scope.slTopci.other.topic,
                            type: $scope.slTopci.other.type
                        });
                    break;
            }
        }
        // 移除
    $scope.pop = function(TID) {
            for (let key in $scope.testPaper) {
                if (typeof $scope.testPaper[key] == "object") {
                    for (var i = 0; i < $scope.testPaper[key].length; i++) {
                        if ($scope.testPaper[key][i].TID == TID) {
                            $scope.testPaper[key].splice(i--, 1);
                        }
                    }
                }
            }
        }
        // 提交
    $scope.submit = function() {
        var other = {}
        for (var i = 0; i < $scope.testPaper.other.length; i++) {
            var one = $scope.testPaper.other[i];
            if (!other[one.type]) {
                other[one.type] = {
                    "title": one.type,
                    topics: []
                }
            }
            other[one.type].topics.push({
                TID: one.TID,
                topic: one.topic
            })
        }
        $scope.testPaper.other = []
        for (var key in other) {
            $scope.testPaper.other.push(other[key])
        }
        console.log(angular.toJson($scope.testPaper))

        $http.post($rootScope.HOST + "/upload_testPaper_GUI_no",
                angular.toJson($scope.testPaper))
            .then(function(res) {
                alert("录入考卷成功")
                $location.url("/listPaper")
            }).catch(function() {
                alert("上传失败")
            })

    }

    $scope.oneKey = function() {
        $scope.reset()
        var num = $scope.tiNum < $scope.allTID.length ? $scope.tiNum : $scope.allTID.length;
        console.log($scope.tiNum + ":::" + $scope.allTID.length)
        var randTID = $scope.randChoice($scope.allTID, num);
        for (let key in $scope.tikuCopy) {
            for (var i = 0; i < $scope.tikuCopy[key].topics.length; i++) {
                if (randTID.indexOf($scope.tikuCopy[key].topics[i].TID) != -1) {
                    var flag = ''
                    switch (key) {
                        case 'topicsCompleted':
                            flag = 'com';
                            break;
                        case 'topicsSingle':
                            flag = 'sin';
                            break;
                        case 'topicsMutiple':
                            flag = 'mul';
                            break;
                        case 'topicsProgram':
                            flag = 'pro';
                            break;
                        case 'topicsOther':
                            flag = 'other';
                            break;
                    }
                    $scope.slTopci[flag] = $scope.tikuCopy[key].topics[i]
                    console.log(flag)
                    $scope.add(flag);
                }
            }
        }
    }

    $scope.randChoice = function(arrList, num) {
        if (num > arrList.length) {
            return;
        }
        var tempArr = arrList.slice(0);
        var newArrList = [];
        for (var i = 0; i < num; i++) {
            var random = Math.floor(Math.random() * (tempArr.length - 1));
            var arr = tempArr[random];
            tempArr.splice(random, 1);
            newArrList.push(arr);
        }
        return newArrList;
    }

})