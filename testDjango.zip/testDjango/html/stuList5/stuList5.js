//  var app = angular.module("app", ['common']);


var stuListCtrl = function($scope, $rootScope, $location, $http) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=stuList")
        return
    }
    $scope.add_QID = parseInt($location.search().QID)

    //增加
       
    $scope.addstuList = function() {
        $scope.add($scope, $http);   
    }

    //删除
        
    $scope.delectstuList = function(index) {       $scope.delect($scope, $http, index);    }    
        //点击修改按钮
             
    $scope.click_update = function(index, list) {        $scope.cli_upd($scope, index, list);        }

    //点击确认修改
         
    $scope.updatestuList = function() {       $scope.update($scope, $http);      }

    //点击按班级添加
    $scope.seekclass = function() {
        $scope.ngshow2 = true;
        $scope.ngshow1 = false;
    }

    //按班级添加——点击确认添加
    $scope.add_stu_class = function() {
        $scope.addclass($scope, $http)
    }

    //按班级添加——选择班级
    $scope.select = function(value) {
        $scope.stuclass = value;
        console.log($scope.stuclass);
    }


    //读取数据
    $scope.init = function($scope, $http) {
        $http.get($rootScope.HOST + "/json/stuList")
            .then(
                (res) => {
                    $scope.stuList5 = angular.fromJson(res.data)
                }
            );
    }

    $scope.initstu = function($scope, $http) {
        $http.get($rootScope.HOST + "/json/student")
            .then(
                (res) => {
                    $scope.student5 = angular.fromJson(res.data)
                }
            );
    }

    //发送数据
    $scope.save = function($scope, $http, value) {
        $http.post(
            $rootScope.HOST + "/json/stuList",
            angular.toJson(value)
        ).then(
            (res) => {
                console.log("发送成功");
            }
        ).catch(
            (err) => {
                console.log("请求出错");
            }
        );
    }

    //增加
    $scope.add = function($scope, $http) {
        var flag = 1;
        for (index in $scope.stuList5) {
            console.log($scope.stuList5[index].QID);
            if (angular.equals($scope.stuList5[index].QID, $scope.add_QID)) {
                alert("这份试卷已经添加过考生学号，您可以对其进行修改！");
                flag = 0;
                break;
            }
        }
        if (angular.equals(flag, 1)) {
            $scope.add_stuList5 = {   
                QID: parseInt($scope.add_QID),
                pwd: $scope.add_pwd,
                stu: $scope.split()   
            };   
            $scope.stuList5.push($scope.add_stuList5);    
            $scope.save($scope, $http, $scope.stuList5);
            alert("增加成功");
        }
        $scope.add_QID = "";   
        $scope.add_pwd = "";   
        $scope.add_stu = "";
    }

    //删除
    $scope.delect = function($scope, $http, index) {
        if (confirm("是否确认删除?")) {
            $scope.stuList5.splice(index, 1);       
            alert("删除成功");
            $scope.save($scope, $http, $scope.stuList5);      
        } else {        alert("你已取消删除！");     }
    }

    //点击修改
    $scope.cli_upd = function($scope, index, list) {
        $scope.ngshow3 = true;    
        $scope.updateQID = list.QID;
        $scope.updatepwd = list.pwd;
        $scope.updatestu = list.stu;
        $scope.inde = index;
    }

    //点击确认修改
    $scope.update = function($scope, $http) {
        if (confirm("是否确认修改?")) {
            $scope.stuList5[$scope.inde].pwd = $scope.updatepwd;
            $scope.stuList5[$scope.inde].stu = $scope.split2();       
            $scope.ngshow3 = false;       
            alert("修改成功");
            $scope.save($scope, $http, $scope.stuList5);      
        } else {        alert("你已取消修改！");     }
    }

    //按班级添加
    $scope.addclass = function($scope, $http) {
        var stustr_array = new Array();
        //console.log($scope.stuclass);

        for (index in $scope.student5) {
            if (angular.equals($scope.student5[index].class, $scope.stuclass)) {
                //console.log(index);
                //console.log($scope.student5[index].stuID);
                stustr_array.push($scope.student5[index].stuID);
                console.log(stustr_array);
            }
        }

        $scope.add_stuList5 = {  
            QID: parseInt($scope.add_QID),
            pwd: $scope.add_pwd,
            stu: stustr_array       
        };       
        $scope.stuList5.push($scope.add_stuList5);    
        $scope.save($scope, $http, $scope.stuList5);
        alert("添加成功");
        $scope.add_QID = "";       
        $scope.add_pwd = "";       
        $scope.add_stu = "";
        $scope.ngshow2 = false;
        $scope.ngshow1 = true;
    }

    //将从textarea接收到的文本按行分割
    $scope.split = function() {
        var stu = document.getElementById("add_stu");
        var stustr = stu.value;
        var stustr_array = new Array();
        stustr_array = stustr.split(/[(\r\n)\r\n]+/);
        return stustr_array;
    }

    //将从textarea接收到的文本按逗号分割
    $scope.split2 = function() {
        var stu = document.getElementById("update_stu");
        var stustr = stu.value;
        var stustr_array = new Array();
        stustr_array = stustr.split(",");
        return stustr_array;
    }


    $scope.inde = 0;
    // save($scope, $http)
    $scope.init($scope, $http);
    $scope.initstu($scope, $http);
    $scope.ngshow1 = true;

}
app.controller("stuListController", stuListCtrl);