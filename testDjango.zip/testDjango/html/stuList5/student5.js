// var app = angular.module("app", []);


var studentCtrl = function($scope, $rootScope, $http, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=student")
        return
    }
    $scope.inde = 0;
    //读取数据
    $scope.init = function($scope, $http) {
        $http.get($rootScope.HOST + "/json/student")
            .then(
                (res) => {
                    $scope.student5 = angular.fromJson(res.data)
                }
            );
    }

    //发送数据
    $scope.save = function($scope, $http, value) {
        $http.post(
            $rootScope.HOST + "/json/student",
            angular.toJson(value)
        ).then(
            (res) => {
                console.log("发送成功");
            }
        ).catch(
            (err) => {
                console.log("请求出错");
            }
        );
    }

    //增加
    $scope.add = function($scope, $http) {
        var flag = 1;
        for (index in $scope.student5) {
            if (angular.equals($scope.student5[index].stuID, $scope.add_stuID)) {
                alert("这名学生已存在，请勿重复添加！");
                flag = 0;
                break;
            }
        }
        if (angular.equals(flag, 1)) {
            $scope.add_student5 = {   
                stuID: $scope.add_stuID,
                name: $scope.add_name,
                class: $scope.add_class,
                college: $scope.add_college,
                school: $scope.add_school,
                pwd: $scope.add_pwd   
            };
            $scope.student5.push($scope.add_student5);  
            $scope.save($scope, $http, $scope.student5);
            console.log("增加成功");
            alert("增加成功");
        }
        $scope.add_stuID = "";
        $scope.add_name = "";
        $scope.add_class = "";
        $scope.add_college = "";
        $scope.add_school = "";
        $scope.add_pwd = "";   
    }

    //删除
    $scope.delect = function($scope, $http, index) {
        if (confirm("是否确认删除?")) {
            $scope.student5.splice(index, 1);       
            alert("删除成功");
            $scope.save($scope, $http, $scope.student5);      
        } else {        alert("你已取消删除！");     }
    }

    //点击修改
    $scope.cli_upd = function($scope, index, list) {
        $scope.ngshow = true;    
        $scope.updatestuID = list.stuID;
        $scope.updatename = list.name;
        $scope.updateclass = list.class;
        $scope.updatecollege = list.college;
        $scope.updateschool = list.school;
        $scope.updatepwd = list.pwd;
        $scope.inde = index;
    }


    //点击确认修改
    $scope.update = function($scope, $http) {
        if (confirm("是否确认修改?")) {
            $scope.student5[$scope.inde].stuID = $scope.updatestuID;
            $scope.student5[$scope.inde].name = $scope.updatename;
            $scope.student5[$scope.inde].class = $scope.updateclass;
            $scope.student5[$scope.inde].college = $scope.updatecollege;
            $scope.student5[$scope.inde].school = $scope.updateschool;
            $scope.student5[$scope.inde].pwd = $scope.updatepwd;       
            $scope.ngshow = false;       
            alert("修改成功");
            $scope.save($scope, $http, $scope.student5);      
        } else {        alert("你已取消修改！");     }
    }

    //将从textarea接收到的文本按行分割
    $scope.split = function() {
        var stu = document.getElementById("add_stu");
        var stustr = stu.value;
        var stustr_array = new Array();
        stustr_array = stustr.split(/[(\r\n)\r\n]+/);
        console.log(stustr_array);
        return stustr_array;
    }


    // save($scope, $http)
    $scope.init($scope, $http)

    //增加
        $scope.addstudent = function() {
        $scope.add($scope, $http);   
    }

    //删除
        
    $scope.delectstu = function(index) {       $scope.delect($scope, $http, index);    }    
        //点击修改按钮
             
    $scope.click_update = function(index, list) {        $scope.cli_upd($scope, index, list);        }

    //点击确认修改
         
    $scope.updatestu = function() {       $scope.update($scope, $http);      }

}
app.controller("studentController", studentCtrl);