// var app = angular.module("app", []);

var stuRegCtrl = function($scope, $rootScope, $location, $http) {
    //读取数据（不能删）
    $scope.init = function($scope, $http) {
        $http.get($rootScope.HOST + "/json/student")
            .then(
                (res) => {
                    console.log(angular.fromJson(res.data))
                    $scope.student5 = angular.fromJson(res.data)
                }
            );
    }

    //发送数据
    $scope.save = function($scope, $http, value) {
        $http.post(
            $rootScope.HOST + "/json/student",
            angular.toJson(value)
        ).then(
            (res) => {
                console.log("发送成功");
            }
        ).catch(
            (err) => {
                console.log("请求出错");
            }
        );
    }

    //注册
    $scope.add = function($scope, $http) {
        var flag = 1;
        for (index in $scope.student5) {
            if (angular.equals($scope.student5[index].stuID, $scope.add_stuID)) {
                alert("您已有账号，请勿重复注册！");
                flag = 0;
                break;
            }
        }
        if (angular.equals(flag, 1)) {

            $scope.add_student5 = {   
                stuID: $scope.add_stuID,
                name: $scope.add_name,
                class: $scope.add_class,
                college: $scope.add_college,
                school: $scope.add_school,
                pwd: $scope.add_pwd   
            };
            $scope.student5.push($scope.add_student5);  
            $scope.save($scope, $http, $scope.student5);
            console.log("注册成功");
            alert("注册成功");
            $scope.add_stuID = "";
            $scope.add_name = "";
            $scope.add_class = "";
            $scope.add_college = "";
            $scope.add_school = "";
            $scope.add_pwd = "";  
        } 
    }


    $scope.inde = 0;

    // save($scope, $http)
    $scope.init($scope, $http);

    //注册
    $scope.addstudent = function() {
        $scope.add($scope, $http);   
    }

}
app.controller("stuRegCtrl", stuRegCtrl);