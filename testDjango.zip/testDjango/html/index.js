/*
这个文件是整个angularJS应用的起点，包括了，定义路由，将各个页面串接起来
*/


angular.module('common', []).filter('unique', function() {
    return function(collection, keyname) {
        //console.info(collection);
        //console.info(keyname);
        var output = [],
            keys = [];
        angular.forEach(collection, function(item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });
        return output;
    }
});


// 定义主模块，注入ngRoute来实现页面路由
var app = angular.module('app', ['ngRoute', 'common']);

// 配置路由页面的 
app.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/check', { templateUrl: 'testPaper4/check.html', controller: 'checkCtrl' })
        .when('/testPaper', { templateUrl: 'testPaper4/testPaper.html', controller: 'paperCtrl' })
        .when('/std', { templateUrl: 'std10/std10.html', controller: 'stdCtrl' })
        .when('/stuList', { templateUrl: 'stuList5/stuList5.html', controller: 'stuListController' })
        .when('/student', { templateUrl: 'stuList5/student5.html', controller: 'studentController' })
        .when('/stuReg', { templateUrl: 'stuList5/stuRegister5.html', controller: 'stuRegCtrl' })
        .when('/teacher', { templateUrl: 'other/teacher.html', controller: 'teacherCtrl' })
        .when("/stuLogin", { templateUrl: 'other/stuLogin.html', controller: 'stuLoginCtrl' })
        .when("/uploadTestPaper", { templateUrl: 'uploadPaperDocx/uploadTestPaper.html', controller: 'testUploadCtrl' })
        .when("/uploadTikuDocx", { templateUrl: 'uploadTikuDocx/uploadTiku.html', controller: 'tikuUploadCtrl' })
        .when("/listPaper", { templateUrl: 'other/listPaper.html', controller: 'listPaperCtrl' })
        .when("/knowledge", { templateUrl: 'knowledge9/knowledge.html', controller: 'KnowCtrl' })
        .when("/tiku", { templateUrl: 'tiku8/tiku8.html', controller: 'tikuController' })
        .when("/answer", { templateUrl: 'answer11/AR1.html', controller: 'answerCtrl' })
        .when("/pingyue", { templateUrl: 'pingyue6/pingyue.html', controller: 'pingyueCtrl' })
        .when("/stuView", { templateUrl: 'other/stuView.html', controller: 'stuViewCtrl' })
        .when("/gui7", { templateUrl: 'gui7/gui7.html', controller: 'gui7Ctrl' })

    .otherwise({ redirectTo: '/stuLogin' });
}]);

// 将字符串转为信任的html文本
app.filter('to_trusted', ['$sce', function($sce) {
    return function(text) {
        return $sce.trustAsHtml(text);
    };
}]);

// 给字符串类添加format函数  可以用 'aaa=%s'.format(xx)
String.prototype.format =   function() {    
    //将arguments转化为数组
    var  args  =  Array.prototype.slice.call(arguments);    
    var  count = 0;  
    return  this.replace(/%s/g,
        function(s, i) {        
            return  args[count++];    
        });
}

// 主控制器
app.controller('mainCtrl', function($scope, $rootScope, $http, $location) {
    $rootScope.HOST = "http://127.0.0.1:8000"
    $rootScope.stuID = localStorage.getItem("stuID")
    $rootScope.teaID = localStorage.getItem("teaID")
})