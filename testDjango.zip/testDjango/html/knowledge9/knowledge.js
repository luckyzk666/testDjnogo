app.controller('KnowCtrl', function($scope, $http, $rootScope, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=knowledge")
        return
    } else {
        $http.get($rootScope.HOST + '/json/tiku').then(function(res) {
            $scope.tiku = angular.fromJson(res.data);
            $scope.topicsCompleted9 = $scope.tiku.topicsCompleted[0] || {};
            $scope.singleChoice9 = $scope.tiku.topicsSingle[0] || {};
            $scope.topicsMutiple9 = $scope.tiku.topicsMutiple[0] || {};
            $scope.topicsProgram9 = $scope.tiku.topicsProgram[0] || {};
            $scope.topicsOther9 = $scope.tiku.topicsOther[0] || {};
            console.log(angular.toJson(res.data));
        }).catch(function() {
            alert("失败");
        });
    }

    $scope.delTiku = function(arr, index) {
        arr.splice(index, 1)
    }

    $scope.knowSplitToArray = function() {
        var tmp = [$scope.topicsCompleted9,
            $scope.singleChoice9,
            $scope.topicsMutiple9,
            $scope.topicsProgram9,
            $scope.topicsOther9
        ]
        for (var i = 0; i < tmp.length; i++) {
            one = tmp[i]
            for (var j = 0; one.topics && j < one.topics.length; j++) {
                ti = one.topics[j]
                ti.knowledges = $scope.mysplit(ti.knowledges)
                console.log(ti.knowledges)
            }
        }
    }

    $scope.check1 = function() {
        //填空
        $scope.knowSplitToArray();
        $scope.submitAll();
    }

    $scope.submitAll = function() {
        $http.post($rootScope.HOST + '/json/tiku',
            angular.toJson($scope.tiku)).then(function() {
            console.log('SUCC');
            alert('提交成功');
            location.reload()
        }).catch(function() {
            console.log("fail");
            alert('提交失败');
        })
        console.log(angular.toJson($scope.tiku));
    }


    $scope.mysplit = function(ss) {
        if (ss == "")
            return []
        res = ss.split(',');
        return res;
    }
    $scope.myMerge = function(Arr) {
        var res = ""
        if (!Arr)
            return res
        for (var i = 0; i < Arr.length; i++) {
            res += Arr[i] + ',';
        }
        res = res.substring(0, res.length - 1)
        return res
    }
    $scope.runEach = function(Arr, fun) {
        var res = [];
        for (var i = 0; i < Arr.length; i++) {
            res.push(fun(Arr[i]))
        }
        return res
    }

})