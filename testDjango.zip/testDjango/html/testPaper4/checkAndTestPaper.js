// 初始化函数， 获取远方数据
function hhq_initialize($scope, $rootScope, $http, $location) {
    if ($location.search().QID) {
        // 获取当前URL中的参数QID，判断是哪份考卷
        $scope.QID = $location.search().QID;
        console.log($scope.QID);
    } else {
        $scope.QID = undefined;
    }
    if (localStorage.getItem("stuID")) {
        $scope.stuID = localStorage.getItem("stuID")
        $rootScope.QID = localStorage.getItem("stuID")
        $scope.pwd = '';
    }
    $http.get($rootScope.HOST + "/json/stuList").then(function(res) {
        $scope.stuList = angular.fromJson(res.data);
        console.log($scope.stuList)
    })
}


// 检查学生合法性的控制器
app.controller('checkCtrl', function($scope, $rootScope, $location, $http) {
    hhq_initialize($scope, $rootScope, $http, $location);

    $scope.check = function() {
        if (!$scope.stuID) {
            alert('不能为空');
        } else {
            // 判断口令是否正确
            var flag = 0;
            for (var i = 0; i < $scope.stuList.length; i++) {
                var item = $scope.stuList[i];
                if (item.QID != $scope.QID) {
                    continue;
                }
                if (item.pwd != $scope.pwd && !$rootScope.stuID) {
                    continue;
                }
                for (var j = 0; j < item.stu.length; j++) {
                    var each = item.stu[j];
                    if (each == $scope.stuID || each == $rootScope.stuID) {
                        flag = 4
                        $rootScope.stuID = each; // 将学号存储到全局变量
                        break;
                    }
                }
            }
            if (flag == 4) {
                // $rootScope.QID = $scope.QID; // 将QID变为全局
                $rootScope.stuID = $scope.stuID;
                $location.url('/testPaper?QID=%s&stuID=%s'.format($scope.QID, $rootScope.stuID))
            } else {
                alert("错误");
            }
        }
    };
});


// 渲染试卷的控制器
app.controller('paperCtrl', function($scope, $rootScope, $location, $http, $interval) {
    if (!$location.search().QID || !$location.search().stuID) { // 如果未验证或者刷新了界面要重新验证
        alert("请先验证身份")
        $location.url("/check");
    }

    // 提示用户考试期间不要刷新
    // window.onbeforeunload = function(e) {
    //     var dialogText = '刷新会损失所有已经填写答案，确认刷新？';
    //     e.returnValue = dialogText;
    //     return dialogText;
    // };


    $scope.QID = $location.search().QID;
    $rootScope.stuID = $location.search().stuID;
    $scope.stuID = $location.search().stuID;
    $http.get($rootScope.HOST + "/get_testPapers/" + $scope.QID).then(function(res) {
        $scope.testPaper = angular.fromJson(res.data);
    })
    $scope.answerSheet = {
        'AID': 0, // 答卷ID是先随便设置
        'QID': parseInt($scope.QID),
        'stuID': $scope.stuID,
        'answers': {}
    };

    // 提交考卷，将相关值转换为标准 答卷对象
    $scope.submit = function() {
        var blank = 0; // 未完成的题目的数量
        if ($scope.testPaper.completion) {
            var comp = $scope.testPaper.completion;
            $scope.answerSheet.answers.completion = [];
            for (var i = 0; i < comp.length; i++) {
                var ASN = [];
                for (var j = 0; j < comp[i].options.length; j++) {
                    var tmp = comp[i].ASN[j] || "";
                    ASN.push(tmp);
                    if (tmp == "") blank++;
                }
                var tmp = {
                    "TID": comp[i].TID,
                    "ASN": ASN
                };
                $scope.answerSheet.answers.completion[i] = tmp;
            }
        }
        if ($scope.testPaper.singleChoice) {
            var item = $scope.testPaper.singleChoice;
            $scope.answerSheet.answers.singleChoice = [];
            for (var i = 0; i < item.length; i++) {
                // item[i].ASN = item[i].ASN || {};
                var ans = parseInt(item[i].ASN[0]) + 1 || -1;
                ans = ans == -1 ? [] : [ans - 1];
                if (ans.length == 0) blank++;
                var tmp = {
                    "TID": item[i].TID,
                    "ASN": ans
                };
                $scope.answerSheet.answers.singleChoice[i] = tmp;
            }
        }
        if ($scope.testPaper.multipleChoice) {
            var item = $scope.testPaper.multipleChoice;
            $scope.answerSheet.answers.multipleChoice = [];
            for (var i = 0; i < item.length; i++) {
                var ASN = [];
                // item[i].ASN = item[i].ASN || {};
                for (var j in item[i].ASN) {
                    if (item[i].ASN[j] == "1")
                        ASN.push(parseInt(j));
                }
                if (ASN.length == 0) blank++;
                var tmp = {
                    "TID": item[i].TID,
                    "ASN": ASN
                };
                $scope.answerSheet.answers.multipleChoice[i] = tmp;
            }
        }
        if ($scope.testPaper.program) {
            var item = $scope.testPaper.program;
            $scope.answerSheet.answers.program = [];
            for (var i = 0; i < item.length; i++) {
                var tmp = {
                    "TID": item[i].TID,
                    "ASN": item[i].ASN || ''
                }
                if (tmp.ASN == '') blank++;
                $scope.answerSheet.answers.program[i] = tmp;
            }
        }
        if ($scope.testPaper.other) {
            var item = $scope.testPaper.other;
            $scope.answerSheet.answers.other = []
            for (var i = 0; i < item.length; i++) {
                $scope.answerSheet.answers.other[i] = [];
                for (var j = 0; j < item[i].topics.length; j++) {
                    var each = item[i].topics;
                    var tmp = {
                        'TID': each[j].TID,
                        'ASN': each[j].ASN || ''
                    };
                    if (tmp.ASN == '') blank++;
                    $scope.answerSheet.answers.other[i][j] = tmp;
                }
            }
        }
        return blank;
    }
    $scope.realSubmit = function(blank) {
        var subflag = true;
        if (blank > 0) {
            var res = confirm("你还有" + blank + "道题目没有完成，是否确认提交？");
            if (!res) {
                subflag = false;
            }
        }
        if (subflag) {
            // console.log(angular.toJson($scope.testPaper));
            console.log(angular.toJson($scope.answerSheet));
            $http.post($rootScope.HOST + '/answerSheet/%s/%s'.format($scope.QID, $scope.stuID),
                    angular.toJson($scope.answerSheet))
                .then(function() {
                    alert("提交成功");
                    $location.url("/stuView")
                })
        }
    }
});