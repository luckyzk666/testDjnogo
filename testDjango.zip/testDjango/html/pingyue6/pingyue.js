app.controller('pingyueCtrl', function($scope, $http, $rootScope, $location) {
    $scope.QID = parseInt($location.search().QID)
    $scope.stuID = $location.search().stuID
    $scope.flag = 0
    $http.get($rootScope.HOST + '/answerSheet/%s/%s'.format($scope.QID, $scope.stuID))
        .then(function(res) {
            $scope.answerSheet = angular.fromJson(res.data);
            console.log($scope.answerSheet.AID);
            $scope.flag++;
            if ($scope.flag >= 3) {
                $scope.shuju()
            }
        }).catch(function() {
            console.log("失败1");
        });
    $http.get($rootScope.HOST + '/answers/%s'.format($scope.QID))
        .then(function(res) {
            $scope.answers = angular.fromJson(res.data);
            console.log(res.data);
            $scope.flag++;
            if ($scope.flag >= 3) {
                $scope.shuju()
            }
        }).catch(function() {
            console.log("失败2");
        });
    $http.get($rootScope.HOST + '/standard/%s'.format($scope.QID)).then(function(res) {
        $scope.standard = angular.fromJson(res.data);
        console.log(res.data);
        $scope.flag++;
        if ($scope.flag >= 3) {
            $scope.shuju()
        }
    }).catch(function(e) {
        console.log("失败3");
        console.log(e)
    });
    $http.get($rootScope.HOST + '/get_testPapers/%s'.format($scope.QID)).then(function(res) {
        $scope.testPaper = angular.fromJson(res.data);
        console.log(res.data);
    }).catch(function(e) {
        console.log("失败4");
    });
    $scope.shuju = function() {
        // console.log($scope.flag);
        // console.log($scope.answers);
        for (var i = 0; i < $scope.answerSheet.answers.other.length; i++) {
            oneSheet = $scope.answerSheet.answers.other[i];
            oneStandard = $scope.standard.answers.other[i];
            oneAnswer = $scope.answers.answers.other[i].answers;
            console.log(oneSheet)
            console.log(oneStandard)
            console.log(oneAnswer)
            for (var j = 0; j < oneSheet.length; j++) {
                oneAnswer[j].STD = oneStandard[j].STD;
                oneAnswer[j].ASN = oneSheet[j].ASN;
            }
            console.log(oneAnswer)
        }
        $scope.keguan()

    }
    $scope.graded = {
        'AID': 110011, // 答卷ID
        'completion': 0,
        'singleChoiceQuestion': 0,
        'multipleChoiceQuestion': 0,
        'program': 0,
        'other': 0,
        'total': 0
    }

    $scope.keguan = function() {
        $scope.graded.completion = 0
        $scope.graded.singleChoiceQuestion = 0
        $scope.graded.multipleChoiceQuestion = 0
        $scope.score = []
        $scope.score2 = []
        $scope.score3 = []
        $scope.score4 = [$scope.score3, $scope.score3, $scope.score3, $scope.score3, $scope.score3, $scope.score3, $scope.score3]
        $scope.sum = [0]
        $scope.m = 0
        $scope.oneScore = [];
        $scope.mulScore = 0;
        // 填空
        for (var i = 0; i < $scope.answers.answers.completion.length; i++) {
            twoSheet = $scope.answerSheet.answers.completion[i];
            twoStandard = $scope.standard.answers.completion[i];
            twoAnswer = $scope.answers.answers.completion[i].answer;
            $scope.score.push([])
            for (var j = 0; j < twoAnswer.length; j++) {
                $scope.score[i].push(0)
                if (twoSheet.ASN[j] == twoAnswer[j]) {
                    $scope.score[i][j] = twoStandard.STD[j]
                    $scope.graded.completion += $scope.score[i][j]
                }
            }
        }
        // 单
        for (var i = 0; i < $scope.answers.answers.singleChoice.length; i++) {
            twoSheet = $scope.answerSheet.answers.singleChoice[i];
            twoStandard = $scope.standard.answers.singleChoice[i];
            twoAnswer = $scope.answers.answers.singleChoice[i];
            $scope.score2.push(0)
            if (twoSheet.ASN[0] == twoAnswer.answer) {

                $scope.score2[i] = twoStandard.STD[twoAnswer.answer]
            }
            $scope.graded.singleChoiceQuestion += $scope.score2[i]
        }
        //多选
        for (var i = 0; i < $scope.answers.answers.multipleChoice.length; i++) {
            var oneAns = $scope.answers.answers.multipleChoice[i]; // 形如{ 'TID': 4,'options': ['80', '443', '996', '8848'],'answer': [1, 2, 3]}
            var oneSheet = $scope.answerSheet.answers.multipleChoice[i]; //{ 'TID': 3, 'ASN': [1, 2] }
            var oneSTD = $scope.standard.answers.multipleChoice[i]; // {'TID': 3,'STD': [0, 2, 0, 1] }
            // console.log(oneAns)
            $scope.oneScore.push(0)
            for (var j = 0; j < oneSheet.ASN.length; j++) {
                var option = oneSheet.ASN[j];
                if (oneSTD.STD[option] == 0) { // 有一道题不对直接给0分
                    $scope.oneScore[i] = 0;
                    break;
                } else { // 否则累加
                    console.log(oneSTD.STD[option])
                    $scope.oneScore[i] += oneSTD.STD[option]
                }
            }
            $scope.mulScore = $scope.mulScore + $scope.oneScore[i]
            console.log("这题得分为: " + $scope.oneScore[i])
        }
        console.log("多选题得分为: " + $scope.mulScore)
    }
    $scope.check = function() {
        //编程题
        //console.log($scope.standard.answers.program[0].grade)
        for (var i = 0; i < $scope.answers.answers.program.length; i++) {
            var question = $scope.standard.answers.program[i];
            $scope.graded.program = question.grade
        }
        for (var i = 0; i < $scope.answers.answers.program.length; i++) {
            var question = $scope.standard.answers.program[i];
            $scope.graded.program = question.grade
        }

        $scope.sum = 0
        for (var i = 0; i < $scope.answers.answers.other.length; i++) {
            // $scope.graded.other[i] = []
            for (var j = 0; j < $scope.answers.answers.other[i].answers.length; j++) {
                // console.log($scope.answers.answers.other[i].answers[j].grade)
                var question = $scope.answers.answers.other[i].answers
                $scope.sum = $scope.sum + question[j].grade
            }
        }

        $scope.graded.AID = parseInt($scope.answerSheet.AID);
        $scope.graded.stuID = $scope.stuID;
        $scope.graded.other = $scope.sum || 0
        $scope.graded.multipleChoiceQuestion = $scope.mulScore || 0
        $scope.graded.total = $scope.graded.completion + $scope.graded.singleChoiceQuestion + $scope.graded.multipleChoiceQuestion + $scope.graded.program + $scope.graded.other
        $http.post($rootScope.HOST + '/graded/%s'.format($scope.graded.AID),
            angular.toJson($scope.graded)).then(function() {
            console.log('SUCC');
            alert('提交成功');
            $location.url('/listPaper')
        }).catch(function() {
            console.log("fail");
            alert('提交失败');
        })
    }

})