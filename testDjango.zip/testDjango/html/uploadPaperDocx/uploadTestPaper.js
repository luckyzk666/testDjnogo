app.controller("testUploadCtrl", function($scope, $http, $rootScope, $location) {
    if (localStorage.getItem("teaID") == null) {
        $location.url("/teacher?url=uploadTestPaper")
        return
    }
    $scope.mess = "消息提醒";
    $scope.submit = function() {
        var form = new FormData();
        var file = $('#myfile')[0].files[0];
        form.append("myfile", file);
        var url = $rootScope.HOST + "/upload_testPaper_CMP";
        $http.post(url, form, {
            headers: {
                'Content-Type': undefined
            }
        }).then(function(res) {
            console.log(res);
            $scope.mess = res.data;
        });
    }
})