// var app = angular.module('app', []);

app.controller('stdCtrl', function($scope, $http, $location, $rootScope) {
    console.log($location.search())
    if ($location.search().QID) {
        $scope.QID = $location.search().QID;
    } else {
        alert('参数错误');
        return;
    }
    var url = $rootScope.HOST + '/get_testPapers/' + $scope.QID
    $http.get(url).then(function(res) {
        $scope.testPaper = angular.fromJson(res.data);
        console.log(res.data);
    }).catch(function() {
        alert("获取考卷失败，QID=%s 的考卷不存在".format($scope.QID));
    });
    $scope.standard = {
        'QID': parseInt($scope.QID), // 表示哪张考卷
        'answers': {
            'completion': [],
            'singleChoice': [],
            'multipleChoice': [],
            'program': [],
            'other': []
        }
    }

    $scope.check = function() {
        //填空
        for (var i = 0; i < $scope.testPaper.completion.length; i++) {
            var question = $scope.testPaper.completion[i];
            $scope.standard.answers.completion[i] = {
                'TID': question.TID,
                'STD': question.STD,
            }
        }
        //单选
        for (var i = 0; i < $scope.testPaper.singleChoice.length; i++) {
            var question = $scope.testPaper.singleChoice[i];
            $scope.standard.answers.singleChoice[i] = {
                'TID': question.TID,
                'STD': question.STD,
            }
        }
        //多选
        for (var i = 0; i < $scope.testPaper.multipleChoice.length; i++) {
            var question = $scope.testPaper.multipleChoice[i];
            $scope.standard.answers.multipleChoice[i] = {
                'TID': question.TID,
                'STD': question.STD,
            }
        }
        //编程题
        for (var i = 0; i < $scope.testPaper.program.length; i++) {
            var question = $scope.testPaper.program[i];
            $scope.standard.answers.program[i] = {
                'TID': question.TID,
                'STD': question.STD || 0,
            }
        }
        for (var i = 0; i < $scope.testPaper.other.length; i++) {
            $scope.standard.answers.other[i] = []
            for (var j = 0; j < $scope.testPaper.other[i].topics.length; j++) {
                console.log($scope.testPaper.other[i].topics[j])
                var question = $scope.testPaper.other[i].topics;
                $scope.standard.answers.other[i][j] = {
                    'TID': question[j].TID,
                    'STD': question[j].STD || 0,
                }
            }

        }

        //将评分标准生成json
        console.log(angular.toJson($scope.standard));
        var url = $rootScope.HOST + '/standard/' + $scope.QID

        $http.post(url, angular.toJson($scope.standard))
            .then(function() {
                console.log('SUCC');
                alert('提交成功');
                $location.url("/listPaper")
            }).catch(function() {
                console.log("fail");
                alert('提交失败');
            });
    }

})