# encoding: utf-8

"""testDjango URL Configuration

"""
from django.contrib import admin
from django.urls import path, re_path
from app1 import views

urlpatterns = [
    re_path('^static/.*$', views.mystatic),  # 自己的静态目录，因为Django的默认静态目录在服务器很难部署
    path('admin/', admin.site.urls),
    path("json", views.all),     # 列出整个json数据库，主要是前期调试的时候方便使用
    path("json/<str:name>", views.getJson), # 获取和设置json
    path("delTestPaper/<int:QID>", views.delTestPaper),  # 删除考卷json
    path("get_testPapers/<int:QID>", views.get_testPaper) , #根据QID获取考卷
    path("upload_testPaper_GUI", views.insert_paper_by_GUI),  # GUI录入题库的接口
    path("upload_testPaper_GUI_no", views.insert_paper_by_GUI_no),  # GUI录入题库的接口,不改变TID
    path("upload_testPaper_CMP", views.insert_paper_by_CMP),  # 用编译器录入题库的借口
    path("answers/<int:QID>", views.answers),  # 根据QID获取和上传answers
    path("standard/<int:QID>", views.standard),  # 根据QID获取和上传评分标准
    path('upload_tiku_cmp', views.upload_tiku_cmp),    # 上传题库docx
    path('upload_tiku_GUI', views.upload_tiku_GUI),    # 上传题库json
    path("answerSheet/<int:QID>/<str:stuID>", views.answerSheet), # 获取和设置案卷
    path("list_testPaper", views.list_testPaper),  # 列出所有考卷
    path("graded/<int:AID>", views.get_graded),   # 根据AID获取和设置graded评阅

    re_path("^.+\.(?:html|js|css|png|map|docx)$", views.files),  # 返回html、js、css等文件
]
